
#define APPLICATION "PIC24 HID Bootloader"
#define VERSION     "1.0"
